

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registration-form');
    const studentTable = document.getElementById('student-table').getElementsByTagName('tbody')[0];

    /*LOCAL STORAGE*/
    function saveToLocalStorage() {
        const students = [];
        document.querySelectorAll('#student-table tbody tr').forEach(row => {
            const cells = row.querySelectorAll('td');
            students.push({
                name: cells[0].textContent,
                id: cells[1].textContent,
                emailid: cells[2].textContent,
                contactNo: cells[3].textContent
            });
        });
        localStorage.setItem('students', JSON.stringify(students));
    }

    function loadFromLocalStorage() {
        const students = JSON.parse(localStorage.getItem('students')) || [];
        students.forEach(student => {
            addStudentToTable(student);
        });
    }

    /*ADDING STUDENT DATA TO TABLE*/

    function addStudentToTable(student) {
        const row = studentTable.insertRow();
        row.insertCell(0).textContent = student.name;
        row.insertCell(1).textContent = student.id;
        row.insertCell(2).textContent = student.emailid;
        row.insertCell(3).textContent = student.contactNo;
        const actionCell = row.insertCell(4);
        actionCell.innerHTML = `
            <button onclick="editStudent(this)">Edit</button><br>
            <button onclick="deleteStudent(this)">Delete</button>
        `;
    }


    window.editStudent = function(button) {
        const row = button.closest('tr');
        document.getElementById('student-name').value = row.cells[0].textContent;
        document.getElementById('student-id').value = row.cells[1].textContent;
        document.getElementById('email-id').value = row.cells[2].textContent;
        document.getElementById('contact-no').value = row.cells[3].textContent;
        row.remove();
        saveToLocalStorage();
    }

    window.deleteStudent = function(button) {
        if (confirm('Are you sure you want to delete this record?')) {
            button.closest('tr').remove();
            saveToLocalStorage();
        }
    }

   /*FORM SUBMIT ACTIVITY */

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('student-name').value.trim();
        const id = document.getElementById('student-id').value.trim();
        const emailid = document.getElementById('email-id').value.trim();
        const contactNo = document.getElementById('contact-no').value.trim();

        if (name && id && emailid && contactNo) {
            const student = { name, id, emailid, contactNo };
            addStudentToTable(student);
            saveToLocalStorage();
            form.reset();
        } else {
            alert('Please fill out all fields.');
        }
    });



    loadFromLocalStorage();
});


/* DESCRIPTION ABOUT THE SYSTEM IN NAVIGATION BAR */

document.addEventListener('DOMContentLoaded', function () {
    var aboutToggle = document.getElementById('about-toggle');
    var aboutSection = document.getElementById('about-section');

    aboutToggle.addEventListener('click', function (event) {
        event.preventDefault();
        if (aboutSection.classList.contains('hidden')) {
            aboutSection.classList.remove('hidden');
        } else {
            aboutSection.classList.add('hidden');
        }
    });
});
